# How to generate the Chrome version

Execute 'npx webpack' in the Chrome folder.

To build : 'web-ext build' (en modifiant éventuellement la version dans le manifest)