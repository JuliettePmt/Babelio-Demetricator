# How to generate the Chrome version

Execute 'npx webpack' **in the Chrome folder**.

To build : 'web-ext build' (en modifiant éventuellement la version dans le manifest)

# NB
Toujours faire les changements dans les fichiers de la version Chrome, modifiés grâce au script "createFirefoxVersion.py".s