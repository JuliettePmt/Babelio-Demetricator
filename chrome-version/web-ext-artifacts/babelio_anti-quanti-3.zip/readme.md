# How to generate the Chrome version

Execute 'npx webpack' in the Chrome folder.